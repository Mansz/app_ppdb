<table border="0" width="100%">
  <tr>
    <td align="center">
      <img src="img/unnamed.png" alt="logo2" width="60">
    </td>
    <td align="center">
      <b style="font-size:23px;">PANITIA PENERIAMAAN PESERTA DIDIK BARU (PPDB)</b> <br>
      <b style="font-size:30px;">SMK NURUL HAYYAH</b> <br>
      <b style="font-size:20px;">TAHUN PELAJARAN <?php echo $thn_ppdb; ?> / <?php echo $thn_ppdb+1; ?></b>
    </td>
    <td align="center">
      <img src="img/unnamed.png" alt="logo2" width="70">
    </td>
  </tr>
  <tr>
    <td colspan="3" align="center" style="font-size:15px;">
      Sekretariat : Jl. Lingkar Provinsi No.07 Bulakelor, Sawah, Ketanggungan, Brebes Regency, Central Java 52263 <img src="img/kode_pos.jpg" alt="Kode Pos." style="margin-bottom:-3px;margin-right:-5px;"> 32382
      <br>
      Website : https://nuha.smkbisa.id//ppdb-online/   e-mail : nuha.smkbisa@gmail.com
    </td>
  </tr>
  <tr>
    <td colspan="3" align="center">
      <hr size="0" color="black" style="margin:0px;margin-bottom:1px;">
      <hr size="2" color="black" style="margin:0px;">
    </td>
  </tr>
</table>
